const jwt = require('jsonwebtoken');
const User = require('../models/User');

const protect = async (req, res, next) => {
  const token = req.cookies?.pillguard_session;

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Not authorized. Please authenticate first.'
    });
  }

  try {
    const secret = process.env.JWT_SECRET;
    if (!secret) throw new Error('JWT_SECRET is not configured.');
    const decoded = jwt.verify(token, secret);

    // Try finding user in MongoDB if connected
    try {
      if (req.app.locals.dbConnected) req.user = await User.findById(decoded.id).select('-password');
    } catch (e) {
      // Fallback
    }

    if (!req.user) return res.status(401).json({ success: false, message: 'Session user no longer exists.' });

    next();
  } catch (err) {
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired token. Please log in again.'
    });
  }
};

// Role authorization
const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `User role '${req.user ? req.user.role : 'anonymous'}' is not authorized to access this action.`
      });
    }
    next();
  };
};

module.exports = { protect, authorize };
