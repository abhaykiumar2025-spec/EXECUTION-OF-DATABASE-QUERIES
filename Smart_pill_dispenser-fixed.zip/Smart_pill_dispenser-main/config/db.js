const mongoose = require('mongoose');
const dns = require('dns');

// Configure reliable DNS servers for Atlas SRV resolution
try {
  dns.setServers(['8.8.8.8', '1.1.1.1']);
} catch (e) {}

let isConnected = false;

const connectDB = async () => {
  const uri = process.env.MONGODB_URI || process.env.LOCAL_MONGODB_URI || 'mongodb://127.0.0.1:27017/smart_pill_dispenser';

  console.log('🔄 Attempting MongoDB Atlas connection to:', uri.replace(/:([^:@]{1,20})@/, ':****@'));

  try {
    const conn = await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 2500,
      connectTimeoutMS: 2500,
    });

    isConnected = true;
    console.log(`✅ MongoDB Connected Successfully: ${conn.connection.host} [Database: ${conn.connection.name}]`);
    return conn;
  } catch (error) {
    console.warn(`⚠️ MongoDB Atlas Connection Notice: ${error.message}`);
    console.warn(`💡 Tip: Update MONGODB_URI in .env with your actual MongoDB Atlas cluster credentials.`);
    console.log(`ℹ️ System running with resilient memory store / live state synchronization.`);
    isConnected = false;
    // Disable command buffering when disconnected to prevent timeouts
    mongoose.set('bufferCommands', false);
    return null;
  }
};

const getDbStatus = () => ({
  connected: isConnected,
  host: isConnected ? mongoose.connection.host : 'Memory/Atlas Fallback',
  dbName: isConnected ? mongoose.connection.name : 'smart_pill_dispenser',
  readyState: mongoose.connection.readyState
});

module.exports = { connectDB, getDbStatus };
