const express = require('express');
const router = express.Router();
const Inventory = require('../models/Inventory');
const ActivityLog = require('../models/ActivityLog');

let inMemoryInventory = [
  { _id: '1', name: 'Metformin HCl', dose: '500mg', currentStock: 21, totalCapacity: 30, refillDate: 'Aug 24, 2026', slot: 3, shape: 'Oblong White', imprint: 'M 500' },
  { _id: '2', name: 'Lisinopril', dose: '10mg', currentStock: 18, totalCapacity: 30, refillDate: 'Aug 20, 2026', slot: 1, shape: 'Round Pink', imprint: 'L 10' },
  { _id: '3', name: 'Multivitamin Complex', dose: 'Daily Supplement', currentStock: 25, totalCapacity: 30, refillDate: 'Aug 15, 2026', slot: 2, shape: 'Softgel Amber', imprint: 'VIT-D' },
  { _id: '4', name: 'Atorvastatin Calcium', dose: '20mg', currentStock: 4, totalCapacity: 30, refillDate: 'Aug 10, 2026', slot: 4, shape: 'Oval White', imprint: 'AT 20' }
];

// GET /api/inventory - Get all cartridge stock
router.get('/', async (req, res) => {
  try {
    const items = await Inventory.find().sort({ slot: 1 });
    if (items && items.length > 0) {
      return res.json({ success: true, data: items });
    }
    return res.json({ success: true, data: inMemoryInventory });
  } catch (err) {
    return res.json({ success: true, data: inMemoryInventory });
  }
});

// POST /api/inventory/refill/:id - Refill specific cartridge
router.post('/refill/:id', async (req, res) => {
  try {
    const amount = parseInt(req.body.amount) || 15;
    let item;

    try {
      item = await Inventory.findById(req.params.id);
      if (item) {
        item.currentStock = Math.min(item.totalCapacity, item.currentStock + amount);
        item.refillDate = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        await item.save();

        await ActivityLog.create({
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          event: `Refilled ${item.name} (+${amount} pills)`,
          status: `Stock: ${item.currentStock}`
        });
      }
    } catch (dbErr) {
      const idx = inMemoryInventory.findIndex(i => i._id === req.params.id);
      if (idx !== -1) {
        inMemoryInventory[idx].currentStock = Math.min(inMemoryInventory[idx].totalCapacity, inMemoryInventory[idx].currentStock + amount);
        inMemoryInventory[idx].refillDate = new Date().toLocaleDateString();
        item = inMemoryInventory[idx];
      }
    }

    res.json({ success: true, data: item, message: `Refilled cartridge successfully.` });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/inventory/refill-all - Refill all slots
router.post('/refill-all', async (req, res) => {
  try {
    try {
      await Inventory.updateMany({}, { $set: { currentStock: 30, refillDate: new Date().toLocaleDateString() } });
      await ActivityLog.create({
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        event: 'Caregiver Performed Full 7-Day Hopper Refill',
        status: 'All 4 Cartridges 100%'
      });
    } catch (dbErr) {
      inMemoryInventory.forEach(item => {
        item.currentStock = item.totalCapacity;
        item.refillDate = new Date().toLocaleDateString();
      });
    }
    res.json({ success: true, message: 'All cartridges refilled to 100% capacity.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/inventory - Add new medication stock
router.post('/', async (req, res) => {
  try {
    const { name, dose, currentStock, totalCapacity, slot, shape, imprint } = req.body;
    let newInv;

    try {
      newInv = await Inventory.create({
        name,
        dose,
        currentStock: currentStock || 30,
        totalCapacity: totalCapacity || 30,
        slot: slot || 5,
        shape: shape || 'Round White',
        imprint: imprint || 'RX'
      });
    } catch (dbErr) {
      newInv = {
        _id: String(Date.now()),
        name,
        dose,
        currentStock: currentStock || 30,
        totalCapacity: totalCapacity || 30,
        slot: slot || 5,
        shape: shape || 'Round White',
        imprint: imprint || 'RX',
        refillDate: new Date().toLocaleDateString()
      };
      inMemoryInventory.push(newInv);
    }

    res.status(201).json({ success: true, data: newInv });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
