const express = require('express');
const router = express.Router();
const Schedule = require('../models/Schedule');
const ActivityLog = require('../models/ActivityLog');

// In-memory cache fallback for resilient execution
let inMemorySchedules = [
  { _id: '1', medName: 'Lisinopril', dosage: '10mg Tablet', time: '08:00 AM', slot: 1, status: 'taken', instructions: 'Take 1 tablet in the morning with breakfast' },
  { _id: '2', medName: 'Multivitamin Complex', dosage: '1 Softgel', time: '01:00 PM', slot: 2, status: 'taken', instructions: 'Take with lunch and a glass of water' },
  { _id: '3', medName: 'Metformin HCl', dosage: '500mg Extended Release', time: '07:00 PM', slot: 3, status: 'pending', instructions: 'Take 1 tablet with evening dinner' },
  { _id: '4', medName: 'Atorvastatin', dosage: '20mg Tablet', time: '09:30 PM', slot: 4, status: 'upcoming', instructions: 'Take at bedtime' }
];

// GET /api/schedules - Get all schedules
router.get('/', async (req, res) => {
  try {
    const schedules = await Schedule.find().sort({ slot: 1 });
    if (schedules && schedules.length > 0) {
      return res.json({ success: true, count: schedules.length, data: schedules });
    }
    return res.json({ success: true, count: inMemorySchedules.length, data: inMemorySchedules });
  } catch (err) {
    return res.json({ success: true, count: inMemorySchedules.length, data: inMemorySchedules });
  }
});

// POST /api/schedules - Add new prescription schedule
router.post('/', async (req, res) => {
  try {
    const { medName, dosage, time, slot, instructions } = req.body;

    if (!medName || !dosage || !time || !slot) {
      return res.status(400).json({ success: false, message: 'Please provide medName, dosage, time, and slot.' });
    }

    let newSchedule;
    try {
      newSchedule = await Schedule.create({
        medName,
        dosage,
        time,
        slot: parseInt(slot),
        instructions: instructions || 'Take as prescribed',
        status: 'upcoming'
      });

      await ActivityLog.create({
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        event: `New Prescription Added: ${medName} (${dosage})`,
        status: `Slot ${slot} Configured`
      });
    } catch (dbErr) {
      newSchedule = {
        _id: String(Date.now()),
        medName,
        dosage,
        time,
        slot: parseInt(slot),
        instructions: instructions || 'Take as prescribed',
        status: 'upcoming'
      };
      inMemorySchedules.push(newSchedule);
    }

    res.status(201).json({ success: true, data: newSchedule });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PUT /api/schedules/:id - Update schedule status
router.put('/:id', async (req, res) => {
  try {
    const { status, time, instructions } = req.body;
    let updated;

    try {
      updated = await Schedule.findByIdAndUpdate(
        req.params.id,
        { $set: { ...(status && { status }), ...(time && { time }), ...(instructions && { instructions }) } },
        { new: true }
      );
    } catch (dbErr) {
      const idx = inMemorySchedules.findIndex(s => s._id === req.params.id);
      if (idx !== -1) {
        if (status) inMemorySchedules[idx].status = status;
        if (time) inMemorySchedules[idx].time = time;
        if (instructions) inMemorySchedules[idx].instructions = instructions;
        updated = inMemorySchedules[idx];
      }
    }

    res.json({ success: true, data: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// DELETE /api/schedules/:id - Delete schedule
router.delete('/:id', async (req, res) => {
  try {
    try {
      await Schedule.findByIdAndDelete(req.params.id);
    } catch (dbErr) {
      inMemorySchedules = inMemorySchedules.filter(s => s._id !== req.params.id);
    }
    res.json({ success: true, message: 'Prescription removed.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
