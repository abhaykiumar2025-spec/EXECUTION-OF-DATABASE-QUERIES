const express = require('express');
const router = express.Router();
const Schedule = require('../models/Schedule');

const pillDatabase = {
  metformin: {
    name: 'Metformin Hydrochloride',
    dose: '500mg Extended Release Tablet',
    match: true,
    shape: 'Oblong / Capsule-Shaped',
    color: 'White / Film-Coated',
    imprint: '"M 500" (Exact Match)',
    confidence: 98.4,
    slot: 3
  },
  lisinopril: {
    name: 'Lisinopril',
    dose: '10mg Oral Tablet',
    match: true,
    shape: 'Round Flat-Faced',
    color: 'Light Pink / Coral',
    imprint: '"L 10" (Exact Match)',
    confidence: 97.8,
    slot: 1
  },
  aspirin: {
    name: 'Aspirin Low Dose',
    dose: '81mg Enteric Coated',
    match: true,
    shape: 'Small Round',
    color: 'Yellow Ochre',
    imprint: '"BAYER 81"',
    confidence: 99.1,
    slot: 2
  },
  atorvastatin: {
    name: 'Atorvastatin Calcium',
    dose: '20mg Tablet',
    match: true,
    shape: 'Oval Convex',
    color: 'White',
    imprint: '"AT 20"',
    confidence: 96.9,
    slot: 4
  },
  wrong_pill: {
    name: 'UNIDENTIFIED RED CAPSULE',
    dose: 'Potential Contaminant / Wrong Medication',
    match: false,
    shape: 'Two-Tone Capsule',
    color: 'Crimson / Black',
    imprint: 'UNKNOWN / NO RECORD',
    confidence: 42.1,
    slot: 0
  }
};

// POST /api/ai/verify - Computer Vision Pill Verification
router.post('/verify', async (req, res) => {
  try {
    const { sampleKey } = req.body;
    const pill = pillDatabase[sampleKey] || pillDatabase.metformin;

    res.json({
      success: true,
      verified: pill.match,
      data: pill,
      safetyStatus: pill.match ? 'SAFE_TO_DISPENSE' : 'HALT_MISMATCH_DETECTED'
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
