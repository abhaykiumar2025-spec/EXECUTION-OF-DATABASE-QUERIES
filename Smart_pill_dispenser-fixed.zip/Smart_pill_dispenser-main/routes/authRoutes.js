const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const { protect } = require('../middleware/auth');

const router = express.Router();
const sessionCookie = 'pillguard_session';
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,}$/;

function publicUser(user) {
    return {
        id: user._id, name: user.name, email: user.email, phone: user.phone,
        role: user.role, patientName: user.patientName, age: user.age,
        weight: user.weight, notes: user.notes, lastLogin: user.lastLogin,
        isEmailVerified: Boolean(user.isEmailVerified)
    };
}

function setSession(res, user) {
    if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET is not configured.');
    const token = jwt.sign({ id: user._id.toString() }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
    res.cookie(sessionCookie, token, {
        httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax',
        maxAge: 7 * 24 * 60 * 60 * 1000, path: '/'
    });
}

function requireDatabase(req, res) {
    if (req.app.locals.dbConnected) return true;
    res.status(503).json({ success: false, message: 'MongoDB is unavailable. Please start MongoDB and try again.' });
    return false;
}

router.post('/register', async (req, res, next) => {
    try {
        if (!requireDatabase(req, res)) return;
        const name = String(req.body.name || '').trim();
        const email = String(req.body.email || '').trim().toLowerCase();
        const password = String(req.body.password || '');
        const role = ['caregiver', 'doctor', 'senior'].includes(req.body.role) ? req.body.role : 'caregiver';
        if (!name || name.length > 100 || !emailPattern.test(email) || !passwordPattern.test(password)) {
            return res.status(400).json({ success: false, message: 'Enter a name, valid email, and strong password with uppercase, lowercase, number, and symbol.' });
        }
        if (await User.exists({ email })) return res.status(409).json({ success: false, message: 'An account with this email already exists.' });
        const user = await User.create({ name, email, password, role, isEmailVerified: true, lastLogin: new Date() });
        setSession(res, user);
        return res.status(201).json({ success: true, message: 'Account created successfully.', user: publicUser(user) });
    } catch (error) { return next(error); }
});

router.post('/login', async (req, res, next) => {
    try {
        if (!requireDatabase(req, res)) return;
        const email = String(req.body.email || '').trim().toLowerCase();
        const password = String(req.body.password || '');
        if (!emailPattern.test(email) || !password) return res.status(400).json({ success: false, message: 'Enter a valid email and password.' });
        const user = await User.findOne({ email }).select('+password');
        if (!user || !(await bcrypt.compare(password, user.password))) return res.status(401).json({ success: false, message: 'Invalid email or password.' });
        user.lastLogin = new Date();
        await user.save({ validateModifiedOnly: true });
        setSession(res, user);
        return res.json({ success: true, message: 'Login successful.', user: publicUser(user) });
    } catch (error) { return next(error); }
});

router.get('/me', protect, (req, res) => res.json({ success: true, user: publicUser(req.user) }));

router.put('/profile', protect, async (req, res, next) => {
    try {
        const { patientName, age, weight, phone, notes } = req.body;
        if (!patientName || !Number.isInteger(Number(age)) || Number(age) < 1 || Number(age) > 120 || !Number.isFinite(Number(weight)) || Number(weight) <= 0 || !/^[+0-9 ()-]{7,}$/.test(phone || '')) return res.status(400).json({ success: false, message: 'Please provide valid patient profile details.' });
        const user = await User.findByIdAndUpdate(req.user._id, { patientName, age: Number(age), weight: Number(weight), phone, notes: notes || '' }, { new: true, runValidators: true });
        return res.json({ success: true, user: publicUser(user) });
    } catch (error) { return next(error); }
});

router.post('/logout', protect, (req, res) => {
    res.clearCookie(sessionCookie, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/' });
    res.json({ success: true, message: 'Logged out successfully.' });
});

router.use((error, req, res, next) => {
    if (res.headersSent) return next(error);
    console.error('Auth error:', error.message);
    res.status(500).json({ success: false, message: 'Authentication service error.' });
});

module.exports = router;
