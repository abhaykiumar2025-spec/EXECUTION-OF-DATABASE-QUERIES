const express = require('express');
const router = express.Router();
const MarRecord = require('../models/MarRecord');
const ActivityLog = require('../models/ActivityLog');

let inMemoryMar = [
  { _id: '1', date: 'Today 08:02 AM', med: 'Lisinopril 10mg', slot: 1, sensor: 'IR & Weight (0.38g)', status: 'Taken On-Time' },
  { _id: '2', date: 'Today 01:04 PM', med: 'Multivitamin 1 Softgel', slot: 2, sensor: 'IR & Weight (0.65g)', status: 'Taken On-Time' },
  { _id: '3', date: 'Yesterday 09:30 PM', med: 'Atorvastatin 20mg', slot: 4, sensor: 'IR & Weight (0.40g)', status: 'Taken On-Time' },
  { _id: '4', date: 'Yesterday 07:15 PM', med: 'Metformin 500mg', slot: 3, sensor: 'IR & Weight (0.42g)', status: 'Taken (15m Delay)' },
  { _id: '5', date: 'Yesterday 01:02 PM', med: 'Multivitamin 1 Softgel', slot: 2, sensor: 'IR & Weight (0.65g)', status: 'Taken On-Time' },
  { _id: '6', date: 'Yesterday 08:05 AM', med: 'Lisinopril 10mg', slot: 1, sensor: 'IR & Weight (0.38g)', status: 'Taken On-Time' }
];

let inMemoryLogs = [
  { _id: '1', time: '08:02 AM', event: 'Slot 1 Lisinopril 10mg Dispensed & Taken', status: 'IR Confirmed' },
  { _id: '2', time: '08:00 AM', event: 'Morning Alarm & Voice Reminder Triggered', status: 'OK' },
  { _id: '3', time: '01:04 PM', event: 'Slot 2 Multivitamin Dispensed & Taken', status: 'IR Confirmed' },
  { _id: '4', time: '01:00 PM', event: 'Noon Alarm Triggered', status: 'OK' }
];

// GET /api/analytics/compliance - Weekly compliance statistics
router.get('/compliance', async (req, res) => {
  try {
    const complianceData = {
      overallRate: 94.2,
      trend: '+4.2% past 7 days',
      dailyRates: [
        { day: 'Mon', rate: 100 },
        { day: 'Tue', rate: 100 },
        { day: 'Wed', rate: 75 },
        { day: 'Thu', rate: 100 },
        { day: 'Fri', rate: 100 },
        { day: 'Sat', rate: 92 },
        { day: 'Sun', rate: 94 }
      ],
      timeBreakdown: {
        morning: 98,
        afternoon: 91,
        evening: 94,
        night: 88
      }
    };
    res.json({ success: true, data: complianceData });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/mar - Medication Administration Records
router.get('/mar', async (req, res) => {
  try {
    const records = await MarRecord.find().sort({ createdAt: -1 });
    if (records && records.length > 0) {
      return res.json({ success: true, data: records });
    }
    return res.json({ success: true, data: inMemoryMar });
  } catch (err) {
    return res.json({ success: true, data: inMemoryMar });
  }
});

// GET /api/logs - Live Activity Sensor Logs
router.get('/logs', async (req, res) => {
  try {
    const logs = await ActivityLog.find().sort({ createdAt: -1 }).limit(20);
    if (logs && logs.length > 0) {
      return res.json({ success: true, data: logs });
    }
    return res.json({ success: true, data: inMemoryLogs });
  } catch (err) {
    return res.json({ success: true, data: inMemoryLogs });
  }
});

// DELETE /api/logs - Clear logs
router.delete('/logs', async (req, res) => {
  try {
    try {
      await ActivityLog.deleteMany({});
    } catch (dbErr) {
      inMemoryLogs = [];
    }
    res.json({ success: true, message: 'Sensor logs cleared.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
