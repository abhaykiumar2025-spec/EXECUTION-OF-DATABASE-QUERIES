const mongoose = require('mongoose');

const ActivityLogSchema = new mongoose.Schema({
  time: {
    type: String,
    required: true
  },
  event: {
    type: String,
    required: true
  },
  status: {
    type: String,
    default: 'OK'
  },
  details: {
    type: String
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('ActivityLog', ActivityLogSchema);
