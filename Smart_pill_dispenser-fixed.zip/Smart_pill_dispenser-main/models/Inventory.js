const mongoose = require('mongoose');

const InventorySchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  dose: {
    type: String,
    required: true
  },
  currentStock: {
    type: Number,
    required: true,
    min: 0,
    default: 30
  },
  totalCapacity: {
    type: Number,
    default: 30
  },
  refillThreshold: {
    type: Number,
    default: 5
  },
  refillDate: {
    type: String,
    default: () => new Date().toLocaleDateString()
  },
  slot: {
    type: Number,
    min: 1,
    max: 7
  },
  shape: {
    type: String,
    default: 'Oblong White'
  },
  imprint: {
    type: String,
    default: 'RX'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Inventory', InventorySchema);
