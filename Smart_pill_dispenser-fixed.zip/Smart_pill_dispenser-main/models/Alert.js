const mongoose = require('mongoose');

const AlertSchema = new mongoose.Schema({
  alertType: {
    type: String,
    enum: ['MISSED_DOSE', 'SOS_EMERGENCY', 'LOW_BATTERY', 'TAMPER_ALERT', 'LOW_STOCK'],
    required: true
  },
  patientName: {
    type: String,
    default: 'Eleanor Hughes'
  },
  caregiverPhone: {
    type: String,
    default: '+1 (555) 234-8901'
  },
  message: {
    type: String,
    required: true
  },
  resolved: {
    type: Boolean,
    default: false
  },
  priority: {
    type: String,
    enum: ['HIGH', 'CRITICAL', 'MEDIUM', 'INFO'],
    default: 'HIGH'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Alert', AlertSchema);
