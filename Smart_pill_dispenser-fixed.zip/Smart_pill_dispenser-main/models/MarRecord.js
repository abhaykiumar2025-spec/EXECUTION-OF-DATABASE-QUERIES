const mongoose = require('mongoose');

const MarRecordSchema = new mongoose.Schema({
  patientName: {
    type: String,
    default: 'Eleanor Hughes'
  },
  date: {
    type: String,
    required: true
  },
  med: {
    type: String,
    required: true
  },
  slot: {
    type: Number,
    required: true
  },
  sensor: {
    type: String,
    default: 'IR Beam & Load Cell Confirmed'
  },
  status: {
    type: String,
    enum: ['Taken On-Time', 'Taken (15m Delay)', 'Missed (Timeout)', 'Rescheduled'],
    default: 'Taken On-Time'
  },
  loadCellGrams: {
    type: Number,
    default: 0.42
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('MarRecord', MarRecordSchema);
