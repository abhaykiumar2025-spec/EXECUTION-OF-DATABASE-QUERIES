const mongoose = require('mongoose');

const ScheduleSchema = new mongoose.Schema({
  patientId: {
    type: String,
    default: 'PATIENT-01'
  },
  medName: {
    type: String,
    required: [true, 'Please provide a medication name'],
    trim: true
  },
  dosage: {
    type: String,
    required: [true, 'Please provide dosage (e.g. 500mg)'],
    trim: true
  },
  time: {
    type: String,
    required: [true, 'Please provide scheduled time (e.g. 08:00 AM)'],
    trim: true
  },
  slot: {
    type: Number,
    required: true,
    min: 1,
    max: 7
  },
  status: {
    type: String,
    enum: ['upcoming', 'pending', 'taken', 'missed'],
    default: 'upcoming'
  },
  instructions: {
    type: String,
    default: 'Take as prescribed with water'
  },
  takenAt: {
    type: Date
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Schedule', ScheduleSchema);
