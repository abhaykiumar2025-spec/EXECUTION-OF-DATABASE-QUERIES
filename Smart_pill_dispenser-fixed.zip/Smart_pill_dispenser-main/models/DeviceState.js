const mongoose = require('mongoose');

const DeviceStateSchema = new mongoose.Schema({
  deviceId: {
    type: String,
    required: true,
    unique: true,
    default: 'ESP32-DISPENSER-01'
  },
  currentSlot: {
    type: Number,
    default: 3,
    min: 1,
    max: 7
  },
  stepperAngle: {
    type: Number,
    default: 102.8
  },
  loadCellWeight: {
    type: Number,
    default: 0.42
  },
  irSensorTripped: {
    type: Boolean,
    default: false
  },
  ledStatus: {
    type: String,
    enum: ['ready', 'dispensing', 'taken', 'missed'],
    default: 'ready'
  },
  batteryLevel: {
    type: Number,
    default: 98
  },
  wifiConnected: {
    type: Boolean,
    default: true
  },
  oledMessage: {
    type: String,
    default: 'SLOT 3: METFORMIN 500mg'
  },
  lastPing: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('DeviceState', DeviceStateSchema);
