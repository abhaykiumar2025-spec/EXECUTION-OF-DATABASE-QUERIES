const Schedule = require('../models/Schedule');
const Inventory = require('../models/Inventory');
const MarRecord = require('../models/MarRecord');
const ActivityLog = require('../models/ActivityLog');
const DeviceState = require('../models/DeviceState');
const User = require('../models/User');

const seedInitialData = async (isDbConnected) => {
  if (!isDbConnected) {
    console.log('ℹ️ Seeder skipped DB write (Memory mode active).');
    return;
  }

  try {
    // 1. Seed Users (Caregiver & Doctor) — upsert so fields stay current
    const demoUsers = [
      {
        name: 'Sarah Hughes',
        email: 'sarah@hughes.care',
        password: 'Caregiver2026!',
        role: 'caregiver',
        patientName: 'Eleanor Hughes',
        phone: '+1 (555) 234-8901',
        isEmailVerified: true
      },
      {
        name: 'Dr. Marcus Vance',
        email: 'dr.vance@cardio.med',
        password: 'Doctor2026!',
        role: 'doctor',
        patientName: 'Eleanor Hughes',
        phone: '+1 (555) 890-1234',
        isEmailVerified: true
      }
    ];

    for (const demo of demoUsers) {
      const existing = await User.findOne({ email: demo.email }).select('+password');
      if (!existing) {
        await User.create(demo);
        console.log(`🌱 Seeded demo user: ${demo.name}`);
      } else if (!existing.isEmailVerified) {
        // Mark pre-existing demo accounts as verified
        existing.isEmailVerified = true;
        await existing.save({ validateModifiedOnly: true });
        console.log(`✅ Updated isEmailVerified for: ${demo.name}`);
      }
    }


    // 2. Check & Seed Schedules
    const scheduleCount = await Schedule.countDocuments();
    if (scheduleCount === 0) {
      await Schedule.create([
        {
          medName: 'Lisinopril',
          dosage: '10mg Tablet',
          time: '08:00 AM',
          slot: 1,
          status: 'taken',
          instructions: 'Take 1 tablet in the morning with breakfast'
        },
        {
          medName: 'Multivitamin Complex',
          dosage: '1 Softgel',
          time: '01:00 PM',
          slot: 2,
          status: 'taken',
          instructions: 'Take with lunch and a glass of water'
        },
        {
          medName: 'Metformin HCl',
          dosage: '500mg Extended Release',
          time: '07:00 PM',
          slot: 3,
          status: 'pending',
          instructions: 'Take 1 tablet with evening dinner'
        },
        {
          medName: 'Atorvastatin',
          dosage: '20mg Tablet',
          time: '09:30 PM',
          slot: 4,
          status: 'upcoming',
          instructions: 'Take at bedtime'
        }
      ]);
      console.log('🌱 Seeded default medication schedules.');
    }

    // 3. Check & Seed Inventory Cartridges
    const invCount = await Inventory.countDocuments();
    if (invCount === 0) {
      await Inventory.create([
        {
          name: 'Metformin HCl',
          dose: '500mg',
          currentStock: 21,
          totalCapacity: 30,
          refillDate: 'Aug 24, 2026',
          slot: 3,
          shape: 'Oblong White',
          imprint: 'M 500'
        },
        {
          name: 'Lisinopril',
          dose: '10mg',
          currentStock: 18,
          totalCapacity: 30,
          refillDate: 'Aug 20, 2026',
          slot: 1,
          shape: 'Round Pink',
          imprint: 'L 10'
        },
        {
          name: 'Multivitamin Complex',
          dose: 'Daily Supplement',
          currentStock: 25,
          totalCapacity: 30,
          refillDate: 'Aug 15, 2026',
          slot: 2,
          shape: 'Softgel Amber',
          imprint: 'VIT-D'
        },
        {
          name: 'Atorvastatin Calcium',
          dose: '20mg',
          currentStock: 4,
          totalCapacity: 30,
          refillDate: 'Aug 10, 2026',
          slot: 4,
          shape: 'Oval White',
          imprint: 'AT 20'
        }
      ]);
      console.log('🌱 Seeded default pill cartridges inventory.');
    }

    // 4. Check & Seed MAR History
    const marCount = await MarRecord.countDocuments();
    if (marCount === 0) {
      await MarRecord.create([
        { date: 'Today 08:02 AM', med: 'Lisinopril 10mg', slot: 1, sensor: 'IR & Weight (0.38g)', status: 'Taken On-Time', loadCellGrams: 0.38 },
        { date: 'Today 01:04 PM', med: 'Multivitamin 1 Softgel', slot: 2, sensor: 'IR & Weight (0.65g)', status: 'Taken On-Time', loadCellGrams: 0.65 },
        { date: 'Yesterday 09:30 PM', med: 'Atorvastatin 20mg', slot: 4, sensor: 'IR & Weight (0.40g)', status: 'Taken On-Time', loadCellGrams: 0.40 },
        { date: 'Yesterday 07:15 PM', med: 'Metformin 500mg', slot: 3, sensor: 'IR & Weight (0.42g)', status: 'Taken (15m Delay)', loadCellGrams: 0.42 },
        { date: 'Yesterday 01:02 PM', med: 'Multivitamin 1 Softgel', slot: 2, sensor: 'IR & Weight (0.65g)', status: 'Taken On-Time', loadCellGrams: 0.65 },
        { date: 'Yesterday 08:05 AM', med: 'Lisinopril 10mg', slot: 1, sensor: 'IR & Weight (0.38g)', status: 'Taken On-Time', loadCellGrams: 0.38 }
      ]);
      console.log('🌱 Seeded default MAR adherence records.');
    }

    // 5. Check & Seed Device State
    const deviceState = await DeviceState.findOne({ deviceId: 'ESP32-DISPENSER-01' });
    if (!deviceState) {
      await DeviceState.create({
        deviceId: 'ESP32-DISPENSER-01',
        currentSlot: 3,
        stepperAngle: 102.8,
        loadCellWeight: 0.42,
        irSensorTripped: false,
        ledStatus: 'ready',
        batteryLevel: 98,
        wifiConnected: true,
        oledMessage: 'SLOT 3: METFORMIN 500mg'
      });
      console.log('🌱 Seeded initial IoT Device State.');
    }

  } catch (err) {
    console.error('Seeder notice:', err.message);
  }
};

module.exports = { seedInitialData };
